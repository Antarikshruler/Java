

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PatientDisplay
 */
@WebServlet("/PatientDisplay")
public class PatientDisplay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientDisplay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Connection con=null;
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/air","root","");
			String query = "select * from airport";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			out.println("<html><head></head><body>"
					+ "<table class='table'style='width:70%'>"
					+ "<tr><th>"
					+ "FlightNo</th>"+"<th>GateNo</th>"+"<th>ArrTime</th>"+"<th>DepTime</th>"+"<th>DestCity</th>"
							+ "</tr>"
									+ "</table></body></html>");
			
			
			out.println("<html><body><table class ='table'style='width:70%' border = none solid red>");
			
			while(rs.next()){
				String flightno = rs.getString(1);
				String gateno = rs.getString(2);
				String arrtime = rs.getString(3);
				String deptime = rs.getString(4);
				String destcity = rs.getString(5);
				
				out.println( "<tr>"
						+ "<td>"+flightno+"</td>"+"<td>"+gateno+"</td>"+"<td>"+arrtime+"</td>"
								+ "<td>"+deptime+"</td>"+"<td>"+destcity+"</td>"
										+ "</tr>");
			}
			String query1 = "select * from airport where destcity='Bangaluru'";
			Statement st1 = con.createStatement();
			ResultSet rs1 = st1.executeQuery(query1);
			
			out.println("<html><head></head><body>"
					+ "<table class='table'style='width:70%'>"
					+ "<tr><th>"
					+ "FlightNo</th>"+"<th>GateNo</th>"+"<th>ArrTime</th>"+"<th>DepTime</th>"+"<th>DestCity</th>"
							+ "</tr>"
									+ "</table></body></html>");
out.println("<html><body><table class ='table'style='width:70%' border = none solid red>");
			
			while(rs1.next()){
				String flightno = rs1.getString(1);
				String gateno = rs1.getString(2);
				String arrtime = rs1.getString(3);
				String deptime = rs1.getString(4);
				String destcity = rs1.getString(5);
				
				out.println( "<tr>"
						+ "<td>"+flightno+"</td>"+"<td>"+gateno+"</td>"+"<td>"+arrtime+"</td>"
								+ "<td>"+deptime+"</td>"+"<td>"+destcity+"</td>"
										+ "</tr>");
			}
		
		
			
			
		}catch(Exception e){
			System.err.println(e.getMessage());
		}finally{
			try{
				if(con!=null){
					con.close();
				}
			}catch(SQLException e){;}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
